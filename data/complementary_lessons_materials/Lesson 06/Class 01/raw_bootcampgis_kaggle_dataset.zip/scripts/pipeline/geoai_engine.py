import os
import pandas as pd
import numpy as np
import json
import zipfile
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import kagglehub
from pathlib import Path
from tqdm import tqdm
import nltk
from rake_nltk import Rake
from dotenv import load_dotenv

# ─── Shared utility (single source of truth) ─────────────────────────────────
from scripts.pipeline.normalize_text import normalize_text  # noqa: F401 (re-exported)

# ─── Data directory (resolved from project root) ─────────────────────────────
_THIS_DIR = Path(__file__).resolve().parent          # scripts/pipeline/
_PROJECT_ROOT = _THIS_DIR.parents[1]                  # bootcampgis_pipeline/

# Load .env variables automatically and silently
load_dotenv(_PROJECT_ROOT / ".env", override=True)

if os.path.exists('/kaggle/working'):
    DATA_DIR = Path('/kaggle/working/data')
else:
    DATA_DIR = _PROJECT_ROOT / "data"


# ─── Download Functions ───────────────────────────────────────────────────────

def download_acs_by_inventory(subset_vars, state, county, year=2021):
    """
    Download ACS (American Community Survey) data from the US Census Bureau API.

    Saves the result to DATA_DIR/<year>/acs/geomarketing_full_stack.csv.
    Returns the cached CSV if it already exists.

    Args:
        subset_vars: List of ACS variable codes (e.g. ['B01003_001E', 'B19013_001E'])
        state: FIPS state code (e.g. '12' for Florida)
        county: FIPS county code (e.g. '057' for Hillsborough)
        year: ACS survey year (default: 2021)

    Returns:
        pd.DataFrame: ACS data with GEOID column, empty DataFrame on failure.
    """
    year_dir = DATA_DIR / str(year) / "acs"
    year_dir.mkdir(parents=True, exist_ok=True)
    target_path = year_dir / "geomarketing_full_stack.csv"

    if target_path.exists():
        return pd.read_csv(target_path)

    base_url = f"https://api.census.gov/data/{year}/acs/acs5"
    get_vars = ",".join(subset_vars)
    url = f"{base_url}?get=NAME,{get_vars}&for=tract:*&in=state:{state}&in=county:{county}"

    census_key = os.environ.get("CENSUS_API_KEY")
    if census_key:
        url += f"&key={census_key}"

    try:
        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.get(url, headers=headers, timeout=60)
        if response.status_code == 200:
            data = response.json()
            df = pd.DataFrame(data[1:], columns=data[0])
            df['GEOID'] = df['state'] + df['county'] + df['tract']
            df = df.drop(columns=['state', 'county', 'tract', 'NAME'])
            for var in subset_vars:
                df[var] = pd.to_numeric(df[var], errors='coerce')
            df.to_csv(target_path, index=False)
            return df
    except Exception as e:
        print(f"[!] Error downloading ACS: {e}")

    return pd.DataFrame()


def download_tiger_by_inventory(subset_layers, state, county, year=2023):
    """
    Download TIGER/Line shapefiles from the US Census Bureau.

    Saves each layer to DATA_DIR/<year>/tiger/<LAYER>/.
    Returns a dict mapping layer name → path to .shp file.

    Args:
        subset_layers: DataFrame with column 'layer_name' (e.g. ['TRACT', 'ROADS'])
        state: FIPS state code (e.g. '12')
        county: FIPS county code (e.g. '057')
        year: TIGER year (default: 2023)

    Returns:
        dict: {layer_name: path_to_shp_file}
    """
    year_dir = DATA_DIR / str(year) / "tiger"
    year_dir.mkdir(parents=True, exist_ok=True)
    paths = {}

    # Layers that use state+county code (not just state)
    COUNTY_LEVEL_LAYERS = ['ROADS', 'AREAWATER', 'EDGES', 'VTD', 'FE_EDGES']

    print(f"[*] Checking/Downloading {len(subset_layers)} TIGER layers...")

    # Resilient session to avoid Census Bureau Timeout
    session = requests.Session()
    retries = Retry(total=5, backoff_factor=1, status_forcelist=[500, 502, 503, 504])
    session.mount('https://', HTTPAdapter(max_retries=retries))
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}

    for layer in tqdm(subset_layers['layer_name'], desc="TIGER Progress"):
        layer = layer.upper()
        layer_dir = year_dir / layer
        layer_dir.mkdir(parents=True, exist_ok=True)

        folder_name = layer

        # Determine geo_code: state+county or state only
        if layer in COUNTY_LEVEL_LAYERS:
            geo_code = f"{state}{county}"
        else:
            geo_code = state

        file_name = f"tl_{year}_{geo_code}_{layer.lower()}.zip"

        # Special naming cases (Census 2023 corrections)
        if layer == "ZCTA5":
            file_name = f"tl_{year}_us_zcta520.zip"
            folder_name = "ZCTA520"
        if layer == "MIL":
            file_name = f"tl_{year}_us_mil.zip"
            folder_name = "MIL"
        if layer == "PUMA":
            file_name = f"tl_{year}_{state}_puma20.zip"
            folder_name = "PUMA"
        if layer == "LANDMARKS":
            file_name = f"tl_{year}_{state}_pointlm.zip"
            folder_name = "POINTLM"
        if layer == "VTD":
            geo_code = state
            file_name = f"tl_{year}_{geo_code}_{layer.lower()}.zip"
            folder_name = "VTD"

        target_zip = layer_dir / file_name

        if not target_zip.exists():
            url = f"https://www2.census.gov/geo/tiger/TIGER{year}/{folder_name}/{file_name}"

            try:
                r = session.get(url, stream=True, timeout=120, headers=headers)
                if r.status_code == 200:
                    total_size = int(r.headers.get('content-length', 0))
                    with tqdm(total=total_size, unit='B', unit_scale=True, desc=f"   -> {layer}", leave=False) as pbar:
                        with open(target_zip, 'wb') as f:
                            for chunk in r.iter_content(chunk_size=8192):
                                if chunk:
                                    f.write(chunk)
                                    pbar.update(len(chunk))
                    with zipfile.ZipFile(target_zip, 'r') as zip_ref:
                        zip_ref.extractall(layer_dir)
                else:
                    # National fallback
                    alt_file = f"tl_{year}_us_{layer.lower()}.zip"
                    if layer == "ZCTA5":
                        alt_file = f"tl_{year}_us_zcta520.zip"
                    if layer == "PUMA":
                        alt_file = f"tl_{year}_us_puma20.zip"
                    if layer == "LANDMARKS":
                        alt_file = f"tl_{year}_us_pointlm.zip"

                    alt_url = f"https://www2.census.gov/geo/tiger/TIGER{year}/{folder_name}/{alt_file}"
                    r_alt = session.get(alt_url, stream=True, timeout=120, headers=headers)
                    if r_alt.status_code == 200:
                        total_size_alt = int(r_alt.headers.get('content-length', 0))
                        with tqdm(total=total_size_alt, unit='B', unit_scale=True, desc=f"   -> {layer} (alt)", leave=False) as pbar_alt:
                            with open(target_zip, 'wb') as f:
                                for chunk in r_alt.iter_content(chunk_size=8192):
                                    if chunk:
                                        f.write(chunk)
                                        pbar_alt.update(len(chunk))
                        with zipfile.ZipFile(target_zip, 'r') as zip_ref:
                            zip_ref.extractall(layer_dir)
                    # Silently skip if layer truly doesn't exist on the server
            except Exception as e:
                print(f"  [!] Error in {layer}: {e}")

        # Locate the extracted .shp file
        for f in os.listdir(layer_dir):
            if f.endswith(".shp"):
                paths[layer] = str(layer_dir / f)

    print(f"✅ TIGER process completed. {len(paths)} layers ready.")
    return paths


def download_gmap_from_kaggle():
    """
    Download GMap Florida dataset from Kaggle via KaggleHub.

    Returns:
        str | None: Path to the gmap_state_florida.csv file, or None if not found.
    """
    print("[*] Downloading GMap via KaggleHub...")
    cache_path = kagglehub.dataset_download("betianalopezandueza/gmap-state-florida")
    for root, dirs, files in os.walk(cache_path):
        for file in files:
            if file.endswith(".csv") and "gmap_state_florida" in file.lower():
                return os.path.join(root, file)
    return None


# ─── GeoAI Engine ─────────────────────────────────────────────────────────────

class GeoAI_Engine:
    """
    NLP processing engine for GMap data.

    Handles:
    - Text normalization (via shared normalize_text module)
    - Embedding generation (via SentenceTransformer)
    - Keyword extraction (via RAKE)
    - Sentiment classification (rule-based)
    - Incremental CSV checkpointing
    """

    def __init__(self):
        nltk.download('stopwords', quiet=True)
        nltk.download('punkt', quiet=True)
        nltk.download('punkt_tab', quiet=True)
        self.rake = Rake()

    def clean_acs_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Clean ACS DataFrame: replace inf/nan, normalize GEOID format, and perform
        robust data cleaning by removing rows with Census special control codes,
        infinites, or NaNs across all columns.

        Args:
            df: Raw ACS DataFrame from download_acs_by_inventory()

        Returns:
            pd.DataFrame: Cleaned and sanitized DataFrame.
        """
        if df.empty:
            return df

        initial_rows = len(df)
        print(f"[*] Starting ACS data sanitation in pipeline. Initial rows: {initial_rows}")

        # Official negative control special codes from the US Census Bureau:
        # -666666666: Median falls in the lowest interval (e.g. <$2,500)
        # -555555555: Median falls in the upper open-ended interval (e.g. >$250,000)
        # -888888888: Estimate not applicable or not available
        # -999999999: Estimate/Margin of error suppressed due to data quality
        # -333333333: Median not applicable or not calculable
        # -222222222: Median falls in the lowest interval/suppressed
        census_special_codes = {-666666666, -888888888, -999999999, -555555555, -333333333, -222222222}

        # Identify numeric columns
        numeric_cols = df.select_dtypes(include=[np.number]).columns

        # Logical mask to identify rows with invalid data that should be removed
        rows_to_remove = pd.Series(False, index=df.index)
        
        dropped_info = {}
        for col in numeric_cols:
            # 1. Identify Census special codes
            special_mask = df[col].isin(census_special_codes)
            count_special = special_mask.sum()
            if count_special > 0:
                dropped_info[col] = count_special
                rows_to_remove = rows_to_remove | special_mask

            # 2. Identify infinite values (inf, -inf)
            inf_mask = np.isinf(df[col])
            count_inf = inf_mask.sum()
            if count_inf > 0:
                print(f"  [!] Column '{col}': Found {count_inf} infinite values. Marking for exclusion.")
                rows_to_remove = rows_to_remove | inf_mask

            # 3. Identify NaNs / Null Values
            nan_mask = df[col].isna()
            count_nan = nan_mask.sum()
            if count_nan > 0:
                print(f"  [!] Column '{col}': Found {count_nan} null/NaN values. Marking for exclusion.")
                rows_to_remove = rows_to_remove | nan_mask

        # Exclusion approach: remove entire rows that contain this corrupted data
        df_clean = df[~rows_to_remove].copy()
        final_rows = len(df_clean)
        dropped_rows = initial_rows - final_rows

        print(f"\n==================================================")
        print(f"ACS DATA SANITATION SUMMARY")
        print(f"==================================================")
        print(f"  - Total raw rows received: {initial_rows}")
        print(f"  - Total rows removed (exclusion): {dropped_rows}")
        print(f"  - Total valid rows preserved: {final_rows}")
        if dropped_info:
            print("  - Details of control codes removed per column:")
            for col, cnt in dropped_info.items():
                print(f"    * Column '{col}': {cnt} records with census special codes")
        print(f"==================================================\n")

        if 'GEOID' in df_clean.columns:
            df_clean['GEOID'] = df_clean['GEOID'].astype(str).str.replace(r'\.0', '', regex=True)
            
        return df_clean

    def process_gmap_nlp(
        self,
        df_input: pd.DataFrame,
        embed_model,
        output_path: str,
        limit: int = None
    ) -> pd.DataFrame:
        """
        NLP enrichment pipeline for GMap data.

        Steps:
        1. Strict text normalization (via shared normalize_text)
        2. Embedding generation (GPU via SentenceTransformer)
        3. Keyword extraction (RAKE with scores)
        4. Rule-based sentiment classification
        5. Incremental CSV checkpointing every 500 records

        Args:
            df_input: Raw GMap DataFrame with 'text' column
            embed_model: SentenceTransformer model instance
            output_path: Path to save the enriched CSV (incremental)
            limit: Maximum number of records to process (default: 50000)

        Returns:
            pd.DataFrame: Enriched DataFrame with embedding, keywords_ai, sentiment columns.
        """
        if limit is not None:
            df = df_input.copy().head(limit).reset_index(drop=True)
        else:
            df = df_input.copy().reset_index(drop=True)

        # 1. Strict normalization
        print("[*] Normalizing texts (Strict Mode)...")
        df['text_normalized'] = df['text'].fillna("").apply(normalize_text)

        # 2. Initialize semantic columns
        df['embedding'] = None
        df['keywords_ai'] = ""
        df['sentiment'] = "neutral"
        df['semantic_json'] = "{}"

        print(f"Starting Enrichment of {len(df)} records...")
        for i in tqdm(range(0, len(df), 500), desc="NLP Batches (500/batch)"):
            end_idx = min(i + 500, len(df))
            chunk = df.iloc[i:end_idx]

            # Embeddings (GPU)
            embeddings = embed_model.encode(
                chunk['text_normalized'].tolist(),
                show_progress_bar=False
            ).tolist()

            for j, emb in enumerate(embeddings):
                idx = i + j
                df.at[idx, 'embedding'] = emb

                # Keywords via RAKE with scores
                self.rake.extract_keywords_from_text(df.at[idx, 'text_normalized'])
                keywords_with_scores = [
                    {"word": phrase, "score": round(score, 2)}
                    for score, phrase in self.rake.get_ranked_phrases_with_scores()[:5]
                ]
                df.at[idx, 'keywords_ai'] = json.dumps(keywords_with_scores)

                # Rule-based sentiment
                text = df.at[idx, 'text_normalized']
                if any(w in text for w in ['good', 'great', 'excellent', 'amazing', 'best']):
                    df.at[idx, 'sentiment'] = 'positive'
                elif any(w in text for w in ['bad', 'worst', 'terrible', 'awful']):
                    df.at[idx, 'sentiment'] = 'negative'

            # Incremental save
            df.head(end_idx).to_csv(output_path, index=False)

        return df
