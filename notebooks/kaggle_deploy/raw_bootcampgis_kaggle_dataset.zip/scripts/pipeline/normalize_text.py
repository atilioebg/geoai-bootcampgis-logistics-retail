import re
import pandas as pd
from unidecode import unidecode


def normalize_text(text) -> str:
    """
    Full text normalization: removes accents, lowercases, strips punctuation.

    Steps:
        1. Handle NaN/None → returns empty string
        2. unidecode: removes accents (é→e, ã→a, ç→c, etc.)
        3. Lowercase + strip whitespace
        4. Regex: keeps only letters, numbers, and spaces (removes !, ?, ., etc.)
        5. Collapses multiple consecutive spaces into one

    Args:
        text: Any value (str, float NaN, None, int, etc.)

    Returns:
        str: Normalized text, empty string if input is null/empty.

    Examples:
        >>> normalize_text("São Paulo!")
        'sao paulo'
        >>> normalize_text("Hello, World! 123")
        'hello world 123'
        >>> normalize_text(None)
        ''
        >>> normalize_text(float('nan'))
        ''
        >>> normalize_text("  multiple   spaces  ")
        'multiple spaces'
    """
    if pd.isna(text):
        return ""
    text = unidecode(str(text).lower().strip())
    text = re.sub(r'[^a-z0-9\s]', '', text)
    return " ".join(text.split())
